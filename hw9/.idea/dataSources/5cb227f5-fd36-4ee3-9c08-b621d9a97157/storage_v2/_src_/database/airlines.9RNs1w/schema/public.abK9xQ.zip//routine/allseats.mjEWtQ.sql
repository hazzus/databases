create function allseats(flightidarg integer)
    returns TABLE(seatno integer)
    language plpgsql
as
$$
declare
    MaxSeat int := (
        select s.SeatNo
        from Seats s
        where PlaneId in (
            select PlaneId
            from Flights
            where FlightId = FlightIdArg
        )
    );
begin
    return query (
        select generate_series as SeatNo
        from generate_series(1, MaxSeat)
    );
end;
$$;

alter function allseats(integer) owner to hazzus;

