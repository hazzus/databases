create function buyfree(flightidarg integer, seatnoarg integer) returns boolean
    language plpgsql
as
$$
begin
    if SeatNoArg not in (select FreeSeats(FlightIdArg)) then
        return false;
    end if;
    insert into Purchases (FlightId, SeatNo)
    values (FlightIdArg, SeatNoArg);
    return true;
end;
$$;

alter function buyfree(integer, integer) owner to hazzus;

