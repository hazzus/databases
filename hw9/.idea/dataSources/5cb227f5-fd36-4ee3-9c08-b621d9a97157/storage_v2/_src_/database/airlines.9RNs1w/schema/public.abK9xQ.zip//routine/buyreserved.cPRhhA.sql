create function buyreserved(useridarg integer, passarg character varying, flightidarg integer, seatnoarg integer) returns boolean
    language plpgsql
as
$$
declare
    Now timestamp := now();
begin
    if not VerifyUser(UserIdArg, PassArg) then
        return false;
    end if;
    delete from Reservations
    where FlightId = FlightIdArg and
          SeatNo = SeatNoArg and
          UserId = UserIdArg and
          ReservationTime + interval '1 day' >= Now;
    if not FOUND then
        return false;
    end if;
    insert into Purchases (FlightId, SeatNo)
    values (FlightIdArg, SeatNoArg);
    return true;
end;
$$;

alter function buyreserved(integer, varchar, integer, integer) owner to hazzus;

