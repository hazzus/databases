create function extendreservation(useridarg integer, passarg character varying, flightidarg integer, seatnoarg integer) returns boolean
    language plpgsql
as
$$
declare
    Now timestamp := now();
begin
    if not VerifyUser(UserIdArg, PassArg) then
        return false;
    end if;
    update Reservations
    set ReservationTime = Now
    where FlightId = FlightIdArg and
          SeatNo = SeatNoArg and
          UserId = UserIdArg and
          ReservationTime + interval '1 day' >= Now;
    return FOUND;
end;
$$;

alter function extendreservation(integer, varchar, integer, integer) owner to hazzus;

