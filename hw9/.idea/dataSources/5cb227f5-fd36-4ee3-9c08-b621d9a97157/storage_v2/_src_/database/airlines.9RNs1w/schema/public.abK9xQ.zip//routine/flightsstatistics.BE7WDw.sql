create function flightsstatistics(useridarg integer, passarg character varying)
    returns TABLE(flightid integer, canreserve boolean, canbuy boolean, freeseat integer, reserved integer, purchased integer)
    language plpgsql
as
$$
declare Now timestamp = now();
begin
    if VerifyUser(UserIdArg, PassArg) then
        return query (
            select f.FlightId,
                   Free > 0,
                   Free > 0 or exists(
                        select UserId
                        from Reservations
                        where UserId = UserIdArg and
                              ReservationTime + interval '1 day' >= Now
                   ),
                   Free,
                   (select count(*)::int from ReservedSeats(f.FlightId)),
                   (select count(*)::int from PurchasedSeats(f.FlightId))
            from Flights f, lateral (select count(*)::int from FreeSeats(f.FlightId)) q(Free) -- WTF should I use q
        );
    end if;
end;
$$;

alter function flightsstatistics(integer, varchar) owner to hazzus;

