create function flightstat(useridarg integer, passarg character varying, flightidarg integer)
    returns TABLE(canreserve boolean, canbuy boolean, free integer, reserved integer, purchased integer)
    language plpgsql
as
$$
declare
    Now timestamp = now();

    AllSeats int := count(AllSeats(FlightIdArg));
    Free int := count(FreeSeats(FlightIdArg));
    Purchased int := (
        select count(SeatNo)
        from AllSeats(FlightIdArg)
        where SeatNo in (
            select SeatNo
            from Purchases
            where FlightId = FlightIdArg
        )
    );
    Reserved int := AllSeats - Free - Purchased;

    CanReserve boolean := Free > 0;
    CanBuy boolean := CanReserve || exists (
        select SeatNo
        from Reservations
        where FlightId = FlightIdArg and
              UserId = UserIdArg and
              ReservationTime + interval '1 day' >= Now
    );
begin
    if not VerifyUser(UserIdArg, PassArg) then
        return query (select);
    end if;
    return query (
        select CanReserve, CanBuy, Free, Reserved, Purchased
    );
end;
$$;

alter function flightstat(integer, varchar, integer) owner to hazzus;

