create function flightstats(useridarg integer, passarg character varying, flightidarg integer)
    returns TABLE(canreserve boolean, canbuy boolean, freeseat integer, reserved integer, purchased integer)
    language plpgsql
as
$$
begin
    if VerifyUser(UserIdArg, PassArg) then
        return query (
            select fs.CanReserve, fs.CanBuy, fs.FreeSeat, fs.Reserved, fs.Purchased
            from FlightsStatistics(UserIdArg, PassArg) fs
            where fs.FlightId = FlightIdArg
        );
    end if;
end;
$$;

alter function flightstats(integer, varchar, integer) owner to hazzus;

