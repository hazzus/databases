create function freeseats(flightidarg integer)
    returns TABLE(freeseatno integer)
    language plpgsql
as
$$
declare
    Now timestamp := now();
begin
    return query (
        select a.SeatNo as FreeSeatNo
        from AllSeats(FlightIdArg) a
        where a.SeatNo not in (
            select SeatNo
            from Reservations
            where FlightId = FlightIdArg and
                  ReservationTime + interval '1 day' > Now
        ) and a.SeatNo not in (
            select SeatNo
            from Purchases
            where FlightId = FlightIdArg
        )
    );
end;
$$;

alter function freeseats(integer) owner to hazzus;

