create function gethash(pass character varying) returns integer
    language plpgsql
as
$$
begin
    return 0;
end;
$$;

alter function gethash(varchar) owner to hazzus;

