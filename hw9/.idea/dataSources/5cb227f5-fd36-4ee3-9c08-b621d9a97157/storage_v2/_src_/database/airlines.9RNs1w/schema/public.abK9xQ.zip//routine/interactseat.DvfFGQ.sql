create function interactseat(actiontype character varying, useridarg integer, passarg character varying, flightidarg integer, seatnoarg integer) returns boolean
    language plpgsql
as
$$
begin
    start transaction read write isolation level serializable;
    if ((ActionType = 'BUY')) then
        return (select BuyFree(FlightIdArg, SeatNoArg));
    else
        if ((ActionType = 'RESERVE')) then
            return (select Reserve(UserIdArg, PassArg, FlightIdArg, SeatNoArg));
        end if;
    end if;
    commit;
end;
$$;

alter function interactseat(varchar, integer, varchar, integer, integer) owner to hazzus;

