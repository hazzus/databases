create function purchasedseats(flightidarg integer)
    returns TABLE(purchasedseats integer)
    language plpgsql
as
$$
begin
    return query (
        select SeatNo
        from AllSeats(FlightIdArg)
        where SeatNo in (
            select SeatNo
            from Purchases
            where FlightId = FlightIdArg
        )
    );
end;
$$;

alter function purchasedseats(integer) owner to hazzus;

