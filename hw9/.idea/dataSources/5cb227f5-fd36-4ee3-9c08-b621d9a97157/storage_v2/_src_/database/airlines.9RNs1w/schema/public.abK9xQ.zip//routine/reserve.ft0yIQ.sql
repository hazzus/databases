create function reserve(useridarg integer, passarg character varying, flightidarg integer, seatnoarg integer) returns boolean
    language plpgsql
as
$$
declare
    Now timestamp := now();
begin
    if not VerifyUser(UserIdArg, PassArg) then
        return false;
    end if;
    if SeatNoArg in (select FreeSeats(FlightIdArg)) then
        insert into Reservations (FlightId, SeatNo, ReservationTime, UserId)
        values (FlightIdArg, SeatNoArg, Now, UserIdArg)
        on conflict (FlightId, SeatNo)
        do update set ReservationTime = Now,
                      UserId = UserIdArg;
        return true;
    end if;
    return false;
end;
$$;

alter function reserve(integer, varchar, integer, integer) owner to hazzus;

