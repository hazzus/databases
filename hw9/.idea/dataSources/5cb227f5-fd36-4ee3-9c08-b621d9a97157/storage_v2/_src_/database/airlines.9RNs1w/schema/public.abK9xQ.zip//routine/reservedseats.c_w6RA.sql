create function reservedseats(flightidarg integer)
    returns TABLE(purchasedseats integer)
    language plpgsql
as
$$
begin
    return query (
        select SeatNo
        from AllSeats(FlightIdArg)
        where SeatNo in (
            select SeatNo
            from Reservations
            where FlightId = FlightIdArg
        )
    );
end;
$$;

alter function reservedseats(integer) owner to hazzus;

