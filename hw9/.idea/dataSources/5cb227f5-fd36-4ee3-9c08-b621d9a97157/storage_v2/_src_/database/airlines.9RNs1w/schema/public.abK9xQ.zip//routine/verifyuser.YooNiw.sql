create function verifyuser(useridarg integer, passarg character varying) returns boolean
    language plpgsql
as
$$
begin
    return exists (
        select UserId
        from Users
        where UserId = UserIdArg and
              PassHash = GetHash(PassArg)
    );
end;
$$;

alter function verifyuser(integer, varchar) owner to hazzus;

